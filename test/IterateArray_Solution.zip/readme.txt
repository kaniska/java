compile:
  java IterateArray*.java

run:
  javac IterateArray

test:
  javac IterateArrayTest